Building moonex
================

See doc/build-*.md for instructions on building the various
elements of the moonex Core reference implementation of moonex.
